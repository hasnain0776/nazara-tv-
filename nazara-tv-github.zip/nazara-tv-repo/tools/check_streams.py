#!/usr/bin/env python3
"""Private IPTV link checker. Standard library only (ffprobe is optional).

Usage:
  python3 check_streams.py links.txt            # check every URL in the file
  python3 check_streams.py links.m3u --html     # also write report.html
  python3 check_streams.py --serve              # small LOCAL web page (127.0.0.1 only)

Input: one URL per line, or an .m3u playlist. Lines starting with # are names/comments.
Passwords in URLs are hidden in the report. Nothing is uploaded anywhere.
"""
import sys, re, json, csv, shutil, subprocess, time, html, argparse
from urllib import request, error
from urllib.parse import urlsplit, urljoin
from concurrent.futures import ThreadPoolExecutor

UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
BLOCK = {401, 403, 407, 451}

def redact(u):
    p = urlsplit(u)
    path = re.sub(r"/live/[^/]+/[^/]+/", "/live/***/***/", p.path)       # xtream-style user/pass
    q = re.sub(r"(token|pass|password|key|mac)=[^&]*", r"\1=***", p.query, flags=re.I)
    return f"{p.scheme}://{p.hostname}{':'+str(p.port) if p.port else ''}{path}{'?'+q if q else ''}"

def fetch(url, timeout, nbytes=4096):
    req = request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with request.urlopen(req, timeout=timeout) as r:
        return r.status, {k.lower(): v for k, v in r.headers.items()}, r.read(nbytes)

def probe(url, timeout):
    """Return (kind, detail). kind: working | dead | blocked"""
    try:
        status, hdr, body = fetch(url, timeout, 8192)
    except error.HTTPError as e:
        return ("blocked" if e.code in BLOCK else "dead"), f"HTTP {e.code}"
    except Exception as e:
        return "dead", type(e).__name__ + (": " + str(getattr(e, "reason", e))[:60])
    text = body.decode("utf-8", "ignore")
    if text.lstrip().startswith("#EXTM3U"):
        lines = [l.strip() for l in text.splitlines() if l.strip() and not l.startswith("#")]
        if not lines:
            return "dead", "empty playlist"
        first = urljoin(url, lines[0])
        try:                                           # follow once: variant playlist or first segment
            s2, h2, b2 = fetch(first, timeout, 2048)
            t2 = b2.decode("utf-8", "ignore")
            if t2.lstrip().startswith("#EXTM3U"):
                segs = [l for l in t2.splitlines() if l.strip() and not l.startswith("#")]
                if segs:
                    fetch(urljoin(first, segs[0].strip()), timeout, 1024)
            return "working", f"HLS ok ({'live' if '#EXT-X-ENDLIST' not in text+t2 else 'vod'})"
        except error.HTTPError as e:
            return ("blocked" if e.code in BLOCK else "dead"), f"playlist ok but media HTTP {e.code}"
        except Exception as e:
            return "dead", "playlist ok but media failed: " + type(e).__name__
    if body[:1] == b"\x47" or (len(body) > 188 and body[188:189] == b"\x47"):
        return "working", "MPEG-TS stream"
    if "html" in hdr.get("content-type", "").lower():
        return "dead", "returned a web page, not a stream"
    return "dead", f"not a stream (HTTP {status}, {hdr.get("content-type","?")})"

def ffprobe_info(url, timeout):
    if not shutil.which("ffprobe"): return ""
    try:
        o = subprocess.run(["ffprobe", "-v", "error", "-rw_timeout", str(timeout*1000000), "-show_entries",
                            "stream=codec_name,width,height", "-of", "csv=p=0", url],
                           capture_output=True, text=True, timeout=timeout+5).stdout.split()
        return " ".join(o[:3])
    except Exception:
        return ""

def load(path):
    items, name = [], None
    for l in open(path, encoding="utf-8", errors="ignore").read().splitlines():
        l = l.strip()
        if not l: continue
        if l.startswith("#EXTINF"): name = l.split(",", 1)[-1].strip(); continue
        if l.startswith("#"): name = l.lstrip("# ").strip() or name; continue
        if re.match(r"^(https?|rtmp)://", l): items.append((name or "", l)); 
        elif l and not l.startswith("http"): name = l
    return items

def run(items, timeout=12, workers=8, use_ffprobe=False):
    def one(it):
        name, url = it; t = time.time()
        if url.startswith("rtmp"): return dict(name=name, url=redact(url), kind="dead", detail="rtmp: browsers/most phone players cannot play", ms=0, info="")
        kind, detail = probe(url, timeout)
        info = ffprobe_info(url, timeout) if (use_ffprobe and kind == "working") else ""
        return dict(name=name, url=redact(url), kind=kind, detail=detail, ms=int((time.time()-t)*1000), info=info)
    with ThreadPoolExecutor(workers) as ex: return list(ex.map(one, items))

def report(rows, html_out=False):
    order = {"working": 0, "blocked": 1, "dead": 2}
    rows.sort(key=lambda r: (order[r["kind"]], r["name"].lower()))
    for r in rows: print(f"[{r['kind'].upper():7}] {r['name'][:28]:28} {r['detail'][:42]:42} {r['url'][:70]}")
    c = {k: sum(r['kind'] == k for r in rows) for k in order}
    print(f"\nworking {c['working']}  blocked {c['blocked']}  dead {c['dead']}  of {len(rows)}")
    json.dump(rows, open("report.json", "w"), indent=1)
    with open("report.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())) if rows else None
        if w: w.writeheader(); w.writerows(rows)
    if html_out:
        col = {"working": "#1a7f37", "blocked": "#b36b00", "dead": "#b42318"}
        tr = "".join(f"<tr><td style='color:{col[r['kind']]};font-weight:700'>{r['kind']}</td><td>{html.escape(r['name'])}</td><td>{html.escape(r['detail'])}</td><td style='word-break:break-all'>{html.escape(r['url'])}</td></tr>" for r in rows)
        open("report.html", "w").write(f"<meta name=viewport content='width=device-width'><body style='font:14px sans-serif'><h3>working {c['working']} / blocked {c['blocked']} / dead {c['dead']}</h3><table border=1 cellpadding=5 style='border-collapse:collapse'>{tr}</table>")
        print("wrote report.html")
    return rows

def serve(port=8765):
    from http.server import BaseHTTPRequestHandler, HTTPServer
    import tempfile, os
    page = "<meta name=viewport content='width=device-width'><body style='font:15px sans-serif;margin:14px'><h3>Private stream checker</h3><form method=post><textarea name=t rows=12 style='width:100%' placeholder='paste links, one per line'></textarea><br><button style='padding:10px 18px;margin-top:8px'>Check</button></form>"
    class H(BaseHTTPRequestHandler):
        def do_GET(s): s.send_response(200); s.send_header("Content-Type", "text/html"); s.end_headers(); s.wfile.write(page.encode())
        def do_POST(s):
            from urllib.parse import parse_qs
            t = parse_qs(s.rfile.read(int(s.headers["Content-Length"])).decode()).get("t", [""])[0]
            f = tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False); f.write(t); f.close()
            rows = run(load(f.name)); os.unlink(f.name)
            col = {"working": "#1a7f37", "blocked": "#b36b00", "dead": "#b42318"}
            tr = "".join(f"<tr><td style='color:{col[r['kind']]}'><b>{r['kind']}</b></td><td>{html.escape(r['name'])}</td><td>{html.escape(r['detail'])}</td><td style='word-break:break-all'>{html.escape(r['url'])}</td></tr>" for r in sorted(rows, key=lambda r: r['kind']!='working'))
            s.send_response(200); s.send_header("Content-Type", "text/html"); s.end_headers(); s.wfile.write((page + f"<table border=1 cellpadding=5 style='border-collapse:collapse'>{tr}</table>").encode())
        def log_message(*a): pass
    print(f"Open http://127.0.0.1:{port} (this computer/phone only). Ctrl+C to stop.")
    HTTPServer(("127.0.0.1", port), H).serve_forever()

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file", nargs="?"); ap.add_argument("--timeout", type=int, default=12)
    ap.add_argument("--workers", type=int, default=8); ap.add_argument("--html", action="store_true"); ap.add_argument("--ffprobe", action="store_true"); ap.add_argument("--serve", action="store_true")
    a = ap.parse_args()
    if a.serve: serve()
    elif a.file: report(run(load(a.file), a.timeout, a.workers, a.ffprobe), a.html)
    else: ap.print_help()
