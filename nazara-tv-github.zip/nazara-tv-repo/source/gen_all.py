import csv,glob,json,os,re
SRC='/home/claude/iptv-org/iptv/streams/'; DB='/home/claude/iptv-org/database/data/'
OUT='/home/claude/nazara/v14/site/data/'; os.makedirs(OUT,exist_ok=True)
existing=set(json.load(open('/home/claude/nazara/v14/channels.json',encoding='utf-8')).keys())
names={r['code'].lower():r['name'] for r in csv.DictReader(open(DB+'countries.csv',encoding='utf-8'))}
ch={r['id']:r for r in csv.DictReader(open(DB+'channels.csv',encoding='utf-8'))}
logo={}
for r in csv.DictReader(open(DB+'logos.csv',encoding='utf-8')):
    u=logo.setdefault(r['channel'],[])
    if r['url'] not in u: u.append(r['url'])
reg={r['code']:set(r['countries'].split(';')) for r in csv.DictReader(open(DB+'regions.csv',encoding='utf-8'))}
def region(cc):
    u=cc.upper()
    for code,label in (('AFR','Africa'),('AMER','Americas'),('ASIA','Asia'),('EUR','Europe'),('APAC','Oceania')):
        if u in reg.get(code,()): return label
    return 'World'
CATMAP={'news':'News','sports':'Sports','kids':'Kids','animation':'Kids','music':'Music','religious':'Religious','movies':'Movies','classic':'Movies','series':'Drama & Entertainment','entertainment':'Drama & Entertainment','comedy':'Drama & Entertainment','family':'Drama & Entertainment'}
bad=re.compile(r"[?&]mac=|play_token=|://[^/]*:[^/]*@|/live/[^/]+/[^/]+/\d+(\.ts)?$",re.I)
files={}
for f in glob.glob(SRC+'*.m3u'):
    p=os.path.basename(f)[:-4].split('_')[0]
    files.setdefault(p,[]).append(f)
meta=[]
for p,fs in sorted(files.items()):
    cc='gb' if p=='uk' else p
    if cc in existing or (cc not in names and cc!='int'): continue
    chans={}
    for f in fs:
        cur=None;opts=False;cid='';geo=False
        for l in open(f,encoding='utf-8',errors='ignore').read().splitlines():
            l=l.strip()
            if l.startswith('#EXTINF'):
                m=re.search(r'tvg-id="([^"]*)"',l); cid=(m.group(1).split('@')[0] if m else '')
                raw=l[l.find(',',l.rfind('"') if '"' in l else 0)+1:].strip()
                opts='http-referrer' in l or 'http-user-agent' in l; geo='[Geo-blocked]' in raw; cur=raw
            elif l.startswith('#EXTVLCOPT') or l.startswith('#EXTHTTP'): opts=True
            elif l.startswith('#') or not l: continue
            elif cur and re.match(r'https?://',l,re.I):
                if opts or bad.search(l): cur=None; continue
                info=ch.get(cid,{})
                if info.get('is_nsfw','').upper()=='TRUE' or 'xxx' in info.get('categories','') or info.get('closed'): cur=None; continue
                q=re.search(r'\((\d{3,4}[pi])\)',cur); q=q.group(1) if q else ''
                name=re.sub(r'\s+',' ',re.sub(r'\[[^\]]*\]','',re.sub(r'\(\d{3,4}[pi]\)','',cur))).strip() or 'Channel'
                k=re.sub(r'[^a-z0-9]','',name.lower())
                cats=[CATMAP[c] for c in info.get('categories','').split(';') if c in CATMAP]
                c=chans.setdefault(k,{'n':name,'c':cats[0] if cats else 'General','s':[],'q':q,'l':(logo.get(cid) or [''])[0],'l2':(logo.get(cid) or [])[1:3],'g':1})
                if l not in c['s'] and len(c['s'])<6: c['s'].append(l)
                if not geo: c['g']=0
                if q and not c['q']: c['q']=q
                cur=None
    items=[]
    for c in chans.values():
        c['s'].sort(key=lambda u:0 if u.startswith('https') else 1); c['h']=1 if c['s'][0].startswith('https') else 0
        if not c['g']: del c['g']
        if not c['l2']: del c['l2']
        items.append(c)
    if not items: continue
    items.sort(key=lambda c:(1 if c.get('g') else 0, 0 if re.match(r'[A-Za-z0-9]',c['n']) else 1, re.sub(r'[^a-z0-9 ]','',c['n'].lower()).strip()))
    json.dump(items,open(OUT+cc+'.json','w',encoding='utf-8'),ensure_ascii=False,separators=(',',':'))
    meta.append({'cc':cc,'name':names.get(cc,'International'),'r':region(cc) if cc!='int' else 'World','n':len(items)})
meta.sort(key=lambda m:(m['r'],m['name']))
json.dump(meta,open('extra.json','w',encoding='utf-8'),ensure_ascii=False,separators=(',',':'))
from collections import Counter
print(len(meta),'countries',sum(m['n'] for m in meta),'channels',Counter(m['r'] for m in meta))
