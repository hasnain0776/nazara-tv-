# Nazara TV logo, version 2: rounded gradient N badge + friendly rounded wordmark. Built from strokes so it looks the same everywhere.
def grad(i): return f'<linearGradient id="{i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff7a3d"/><stop offset="1" stop-color="#ff2e6e"/></linearGradient>'
LET = {"N":"M0,40 L0,0 L28,40 L28,0","A":"M2,40 L14,0 L26,40 M7,27 H21","Z":"M0,0 H28 L0,40 H28","R":"M0,40 L0,0 L16,0 Q28,0 28,11 Q28,22 16,22 L0,22 M15,22 L28,40"}
def badge(gid):
    return (f'<rect width="64" height="64" rx="17" fill="url(#{gid})"/>'
            '<path d="M20 46 V19 L44 46 V19" fill="none" stroke="#fff" stroke-width="6.5" stroke-linecap="round" stroke-linejoin="round"/>'
            '<circle cx="50.5" cy="13.5" r="3.6" fill="#fff"/>')
def lockup(gid, word="#ffffff", extra=""):
    ls = "".join(f'<path transform="translate({i*40},0)" d="{LET[c]}"/>' for i,c in enumerate("NAZARA"))
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 396 64" {extra}><defs>{grad(gid)}</defs>{badge(gid)}'
            f'<g transform="translate(82,12)" fill="none" stroke="{word}" stroke-width="6" stroke-linecap="round" stroke-linejoin="round">{ls}</g>'
            f'<g transform="translate(82,12)"><rect x="248" y="0" width="58" height="40" rx="11" fill="url(#{gid})"/>'
            '<g fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"><path d="M259,11 H277 M268,11 V30"/><path d="M283,11 L291,30 L299,11"/></g></g></svg>')
def icon(gid, extra=""):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" {extra}><defs>{grad(gid)}</defs>{badge(gid)}</svg>'
