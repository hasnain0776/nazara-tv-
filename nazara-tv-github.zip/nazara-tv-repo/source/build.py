import sys, re, json, urllib.parse
sys.path.insert(0,'/home/claude/nazara/v7')
from logo2 import *
VER="1.1.0"
t=open('head.html',encoding='utf-8').read()+open('js.part',encoding='utf-8').read()
data=open('/home/claude/nazara/v14/channels.json',encoding='utf-8').read()
extra=open('/home/claude/nazara/v14/extra.json',encoding='utf-8').read()
xm=json.loads(extra)
total=sum(len(v) for v in json.loads(data).values())+sum(m['n'] for m in xm)
h=(t.replace('{{LOGO}}',lockup('gl')).replace('{{LOGO2}}',lockup('gs')).replace('{{FAVICON}}',"data:image/svg+xml,"+urllib.parse.quote(icon('gf'))).replace('{{TOTAL}}',f"{total:,}").replace('{{NC}}',str(len(json.loads(data))+len(xm))).replace('{{VER}}',VER).replace('/*DATA*/null',data).replace('/*EXTRA*/[]',extra))
assert '{{' not in h
open('index.html','w',encoding='utf-8').write(h)
S='/tmp/claude-0/-home-claude/3c2815d9-3f5f-5ca9-b901-0671f94cca96/scratchpad/'
for i,s in enumerate(re.findall(r'<script>(.*?)</script>',h,re.S)): open(f'{S}v14s{i}.js','w',encoding='utf-8').write(s)
print("built")
