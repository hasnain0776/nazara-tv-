# Site source
`head.html` (page + styles) and `js.part` (app code) are joined by `build.py` into `index.html`.
`gen_all.py` makes the per-country files in `site/data/` from the open iptv-org data.
The scripts use absolute paths from the original workspace. Edit the paths at the top before running them on your own machine.
Channel data for the built-in countries is in `channels.json`.
