"""Small fixes applied to the generated Android project: keep the screen awake while watching, allow plain-http streams."""
import re, pathlib
root = pathlib.Path("android/app/src/main")
act = root / "java/com/nazara/tv/MainActivity.java"
act.parent.mkdir(parents=True, exist_ok=True)
act.write_text("""package com.nazara.tv;

import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}
""")
mf = root / "AndroidManifest.xml"
x = mf.read_text()
if "usesCleartextTraffic" not in x:
    x = x.replace("<application", '<application\n        android:usesCleartextTraffic="true"', 1)
x = x.replace('android:allowBackup="true"', 'android:allowBackup="false"')
mf.write_text(x)
print("patched", act, mf)
