"""Fixes applied to the generated Android project: keep the screen awake, real full screen + landscape for the player,
allow plain-http streams, and fetch video through the phone itself so that servers that block browsers (CORS) still play."""
import pathlib
root = pathlib.Path("android/app/src/main")
act = root / "java/com/nazara/tv/MainActivity.java"
act.parent.mkdir(parents=True, exist_ok=True)
act.write_text(r'''package com.nazara.tv;

import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends BridgeActivity {
    private boolean fsOn = false;
    private boolean bridged = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!bridged && getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().addJavascriptInterface(new NativeFs(), "NazaraNative");
            getBridge().setWebViewClient(new MediaClient(getBridge()));
            bridged = true;
        }
    }

    private class NativeFs {
        @JavascriptInterface
        public void setFullscreen(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyFs(on);
                }
            });
        }
    }

    private void applyFs(boolean on) {
        fsOn = on;
        View d = getWindow().getDecorView();
        if (on) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            d.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && fsOn) applyFs(true);
    }

    /* Video requests made by the page go through the phone's own network code, so a server that refuses browsers (no CORS) still answers. */
    private class MediaClient extends BridgeWebViewClient {
        MediaClient(com.getcapacitor.Bridge bridge) {
            super(bridge);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            try {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                String host = u.getHost();
                if (("http".equals(scheme) || "https".equals(scheme)) && host != null && !"localhost".equals(host)) {
                    Map<String, String> rh = request.getRequestHeaders();
                    boolean cross = rh != null && (rh.containsKey("Origin") || rh.containsKey("origin"));
                    String path = u.getPath() == null ? "" : u.getPath().toLowerCase();
                    boolean media = path.endsWith(".m3u8") || path.endsWith(".ts") || path.endsWith(".m4s") || path.endsWith(".aac")
                        || path.endsWith(".mp4") || path.endsWith(".key") || path.endsWith(".cmfv") || path.endsWith(".cmfa") || path.endsWith(".mp3");
                    if (cross || media) {
                        WebResourceResponse r = fetchThrough(request);
                        if (r != null) return r;
                    }
                }
            } catch (Throwable t) {
                /* fall through to the normal path */
            }
            return super.shouldInterceptRequest(view, request);
        }

        private Map<String, String> cors(Map<String, String> h) {
            h.put("Access-Control-Allow-Origin", "*");
            h.put("Access-Control-Allow-Headers", "*");
            h.put("Access-Control-Allow-Methods", "GET, OPTIONS");
            h.put("Access-Control-Expose-Headers", "*");
            return h;
        }

        private WebResourceResponse fetchThrough(WebResourceRequest req) {
            try {
                String method = req.getMethod();
                if ("OPTIONS".equals(method)) {
                    return new WebResourceResponse("text/plain", "UTF-8", 200, "OK", cors(new HashMap<String, String>()), new ByteArrayInputStream(new byte[0]));
                }
                if (!"GET".equals(method)) return null;
                String url = req.getUrl().toString();
                HttpURLConnection c = null;
                int code = 0;
                for (int i = 0; i < 6; i++) {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(12000);
                    c.setReadTimeout(30000);
                    Map<String, String> rh = req.getRequestHeaders();
                    if (rh != null) {
                        for (Map.Entry<String, String> e : rh.entrySet()) {
                            String kl = e.getKey().toLowerCase();
                            if (kl.equals("origin") || kl.equals("referer") || kl.equals("host") || kl.equals("accept-encoding")) continue;
                            c.setRequestProperty(e.getKey(), e.getValue());
                        }
                    }
                    code = c.getResponseCode();
                    if (code >= 300 && code < 400) {
                        String loc = c.getHeaderField("Location");
                        c.disconnect();
                        if (loc == null) return null;
                        url = new URL(new URL(url), loc).toString();
                        c = null;
                        continue;
                    }
                    break;
                }
                if (c == null) return null;
                InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                if (in == null) in = new ByteArrayInputStream(new byte[0]);
                String ct = c.getContentType();
                String mime = "application/octet-stream";
                String enc = null;
                if (ct != null) {
                    String[] parts = ct.split(";");
                    mime = parts[0].trim();
                    for (int k = 1; k < parts.length; k++) {
                        String p = parts[k].trim();
                        if (p.toLowerCase().startsWith("charset=")) enc = p.substring(8).trim();
                    }
                }
                Map<String, String> out = new HashMap<String, String>();
                for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
                    String k = e.getKey();
                    if (k == null || e.getValue() == null || e.getValue().isEmpty()) continue;
                    String kl = k.toLowerCase();
                    if (kl.equals("content-encoding") || kl.equals("content-length") || kl.equals("transfer-encoding") || kl.equals("connection") || kl.startsWith("access-control-")) continue;
                    out.put(k, e.getValue().get(0));
                }
                cors(out);
                String reason = c.getResponseMessage();
                if (reason == null || reason.length() == 0) reason = "OK";
                return new WebResourceResponse(mime, enc, code, reason, out, in);
            } catch (Throwable t) {
                return null;
            }
        }
    }
}
''')
mf = root / "AndroidManifest.xml"
x = mf.read_text()
if "usesCleartextTraffic" not in x:
    x = x.replace("<application", '<application\n        android:usesCleartextTraffic="true"', 1)
x = x.replace('android:allowBackup="true"', 'android:allowBackup="false"')
mf.write_text(x)
print("patched", act, mf)
